//
//  AIRGoogleMapMarkerManager.h
//  AirMaps
//
//  Created by Gil Birman on 9/2/16.
//

#import <React/RCTViewManager.h>

@interface AIRGoogleMapMarkerManager : RCTViewManager

@end
