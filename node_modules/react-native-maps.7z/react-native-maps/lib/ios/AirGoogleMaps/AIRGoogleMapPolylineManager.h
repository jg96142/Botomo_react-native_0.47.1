//
//  AIRGoogleMapPolylineManager.h
//
//  Created by Nick Italiano on 10/22/16.
//

#import <React/RCTViewManager.h>

@interface AIRGoogleMapPolylineManager : RCTViewManager

@end
