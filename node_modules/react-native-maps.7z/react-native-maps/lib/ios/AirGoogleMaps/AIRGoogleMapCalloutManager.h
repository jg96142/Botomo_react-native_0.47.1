//
//  AIRGoogleMapCalloutManager.h
//  AirMaps
//
//  Created by Gil Birman on 9/6/16.
//
//
#import <React/RCTViewManager.h>

@interface AIRGoogleMapCalloutManager : RCTViewManager

@end
