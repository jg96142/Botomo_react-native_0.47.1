//
//  AIRGMSPolyline.m
//  AirMaps
//
//  Created by Guilherme Pontes 04/05/2017.
//

#import "AIRGMSPolyline.h"

@implementation AIRGMSPolyline
@end
