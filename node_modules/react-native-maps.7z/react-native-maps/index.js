import MapView from './lib/components/MapView';

module.exports = MapView;
